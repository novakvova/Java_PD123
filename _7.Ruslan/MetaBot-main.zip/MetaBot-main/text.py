

hello_text = """Привіт
Для початку обробки відправ фото/відео,
файлом без стискання."""

agree_text = "Так, продовжимо"
disagree_text = "Ні, закінчимо"

color_img_text = "Накласти корекцію кольору"
blur_img_text = "Накласти блюр"
pixel_img_text = "Накласти пікселізацію"
choose_img_text = "Виберіть фото фото"
get_count_img_text = "Введіть кількість варіацій фото від 1 до 20:"
get_count_video_text = "Введіть силу накладення ефекту від 1 до 5:"
color_video_text = "Накласти корекцію кольору відео"
brightness_video_text = "Змінити яксравіть відео"
blur_video_text = "Накласти блюр на відео"
pixel_video_text = "Накласти пікселізацію на відео"
speed_video_text = "Змінити швидкість відео"

speed_text_1 ="1.25x"
speed_text_2 ="1.5x"
speed_text_3 ="1.75x"
speed_text_4 ="2x"

error_type_text = "Невідомий тип документу."
error_photo_type_text ="Будь ласка, відправте фото без стискання>"
error_file_is_big = "Помилка: Розмір файлу завеликий"

get_count_status = ""